import React, { Component } from 'react'
import { Link } from 'react-router-dom'

export default class HomeScreen extends Component {
    render() {
        return (
            <div>
                <h1>Product category</h1>
                <Link to="/women_clothes">
                <h3>Women wear</h3>
                </Link>
                <Link to="/men_clothes">
                <h3>Mens wear</h3>
                </Link>
            </div>
        )
    }
}
