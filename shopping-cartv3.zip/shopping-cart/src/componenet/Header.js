import React from 'react'

export default function Header() {
    return (
        <div className="grid-container">
            <div className='shail'>
              <a href="/">React Shopping Cart</a>
            </div>
        </div>
    )
}
